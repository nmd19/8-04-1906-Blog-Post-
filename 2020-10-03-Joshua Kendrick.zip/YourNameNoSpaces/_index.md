---
# Display name
name: Your Name

authors:
- YourNameNoSpaces

superuser: no

# Role/position
role: Student

# Organizations/Affiliations
organizations:
- name: Florida State University
  url: "https://fsu.edu"

# Short bio (displayed in user profile at end of posts)
bio: The author, a student at Florida State University, was enrolled in the digital microhistory lab in fall 2019.

interests:

education:

social:
- icon: twitter
  icon_pack: fab
  link: https://twitter.com/
- icon: github
  icon_pack: fab
  link: https://github.com/<!-- your github username -->

user_groups:
- Writers
---
The author, a student at Florida State University, was enrolled in the digital microhistory lab in fall 2019.


