---
title: "<!--insert-->"
subtitle: "" <!--optional-->
summary: "<!--insert-->"
authors: [<!--YourFullNameNoSpaces-->]
tags: ["<!--insert-->", "<!--insert-->" <!--add more as needed-->]
categories: [curiosities]
date: YYYY-MM-DD <!--today's date-->
featured: false
draft: false
image:
  caption: "<!--insert caption, perhaps including date of issue in which feature image appears-->"
  focal_point: "Smart"
  preview_only: true
projects: []
---
Insert text here in Markdown format.

If you want to include other images, add the image file to the folder containing this file, and use this format:

![image-name](image-filename.png "Caption")
